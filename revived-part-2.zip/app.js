const toggle=document.querySelector('.menu-toggle');
const nav=document.querySelector('nav');
const triggers=[...document.querySelectorAll('.nav-trigger')];
function closeGroups(except){triggers.forEach(b=>{if(b!==except)b.setAttribute('aria-expanded','false');});}
toggle.addEventListener('click',()=>{const open=toggle.getAttribute('aria-expanded')!=='true';toggle.setAttribute('aria-expanded',String(open));nav.classList.toggle('open',open);if(!open)closeGroups();});
triggers.forEach(b=>b.addEventListener('click',()=>{const open=b.getAttribute('aria-expanded')!=='true';closeGroups(b);b.setAttribute('aria-expanded',String(open));}));
document.addEventListener('click',e=>{if(!e.target.closest('header')){closeGroups();nav.classList.remove('open');toggle.setAttribute('aria-expanded','false');}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){const active=triggers.find(b=>b.getAttribute('aria-expanded')==='true');closeGroups();if(active)active.focus();else if(nav.classList.contains('open')){nav.classList.remove('open');toggle.setAttribute('aria-expanded','false');toggle.focus();}}});
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{closeGroups();nav.classList.remove('open');toggle.setAttribute('aria-expanded','false');}));

const slideshow=document.querySelector('.hero-slideshow');
if(slideshow){
 const slides=[...slideshow.querySelectorAll('.hero-slide')];
 const control=document.querySelector('.hero-pause');
 const motion=window.matchMedia('(prefers-reduced-motion: reduce)');
 let index=0,paused=motion.matches,timer;
 function schedule(){
  clearInterval(timer);
  const label=paused?'Play slideshow':'Pause slideshow';
  control.innerHTML=paused?'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6 3.5 16 10 6 16.5Z" fill="currentColor"/></svg>':'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6 4v12M14 4v12" stroke="currentColor" stroke-width="3"/></svg>';
  control.setAttribute('aria-label',label);
  control.title=label;
  if(paused||document.hidden)return;
  timer=setInterval(()=>{
   const next=(index+1)%slides.length;
   if(!slides[next].complete||!slides[next].naturalWidth)return;
   slides[index].classList.remove('is-active');
   slides[next].classList.add('is-active');
   index=next;
  },5000);
 }
 control.hidden=false;
 control.addEventListener('click',()=>{paused=!paused;schedule();});
 document.addEventListener('visibilitychange',schedule);
 motion.addEventListener('change',()=>{paused=motion.matches;schedule();});
 schedule();
}
