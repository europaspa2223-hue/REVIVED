/* Optional GA4 page views. No tag is loaded until a visitor accepts. */
(() => {
  'use strict';
  const id = 'G-W7ZZTEM42N';
  const key = 'revived-analytics-choice-v1';
  // Appointment forms and unknown routes never load Analytics.
  const canonical = document.querySelector('link[rel="canonical"]');
  if (!canonical || location.pathname.startsWith('/book')) return;
  const page = new URL(canonical.href);
  if (page.origin !== 'https://www.revivedclinic.com') return;
  let started = false;
  let choice = null;
  try { choice = localStorage.getItem(key); } catch (_) {}
  function start() {
    if (started) return;
    started = true;
    window['ga-disable-' + id] = false;
    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    window.gtag('consent', 'default', {
      analytics_storage: 'granted', ad_storage: 'denied',
      ad_user_data: 'denied', ad_personalization: 'denied'
    });
    window.gtag('js', new Date());
    window.gtag('config', id, {
      send_page_view: true,
      page_location: page.origin + page.pathname,
      page_referrer: '',
      page_title: document.title,
      allow_google_signals: false,
      allow_ad_personalization_signals: false
    });
    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://www.googletagmanager.com/gtag/js?id=' + id;
    document.head.appendChild(script);
  }
  const panel = document.createElement('section');
  panel.setAttribute('aria-label', 'Optional website analytics');
  panel.style.cssText = 'position:fixed;bottom:16px;left:16px;right:16px;max-width:640px;margin:auto;z-index:10000;padding:20px;background:#fffaf3;color:#302421;border:1px solid #a89080;border-radius:8px;box-shadow:0 4px 28px #0003;font:15px/1.5 Arial,sans-serif';
  panel.innerHTML = '<strong>Optional website analytics</strong><p style="margin:8px 0 14px">With your permission, we use Google Analytics cookies to understand visits to our public website. Google receives basic visit information. We do not track the appointment-booking page or collect form entries. Your choice will be saved on this device. <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer">Google privacy information</a></p><div style="display:flex;gap:12px;flex-wrap:wrap"></div>';
  function choose(value) {
    choice = value;
    try { localStorage.setItem(key, value); } catch (_) {}
    panel.hidden = true;
    if (value === 'accepted') start();
    else {
      window['ga-disable-' + id] = true;
      // Reload after withdrawal so the previously loaded library is removed.
      if (started) location.reload();
    }
    settings.focus();
  }
  ['Decline', 'Accept analytics'].forEach((text, i) => {
    const button = document.createElement('button');
    button.type = 'button'; button.textContent = text;
    button.style.cssText = 'padding:10px 16px;border:1px solid #663a44;border-radius:4px;background:white;color:#663a44;font:inherit;cursor:pointer';
    button.addEventListener('click', () => choose(i ? 'accepted' : 'declined'));
    panel.lastElementChild.appendChild(button);
  });
  const settings = document.createElement('button');
  settings.type = 'button'; settings.textContent = 'Analytics preferences';
  settings.style.cssText = 'margin:16px;padding:8px 12px;border:1px solid currentColor;background:transparent;color:inherit;cursor:pointer;font:inherit';
  settings.addEventListener('click', () => { panel.hidden = false; panel.querySelector('button').focus(); });
  (document.querySelector('footer') || document.body).appendChild(settings);
  panel.hidden = choice === 'accepted' || choice === 'declined';
  document.body.appendChild(panel);
  if (choice === 'accepted') start();
})();
